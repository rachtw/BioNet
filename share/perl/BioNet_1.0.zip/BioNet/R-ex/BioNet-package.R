### Name: BioNet-package
### Title: What the package does (short line) ~~ package title ~~
### Aliases: BioNet-package BioNet
### Keywords: package

### ** Examples

~~ simple examples of the most important functions ~~



